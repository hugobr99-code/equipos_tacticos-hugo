<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Monument;
use App\Models\Coordinate;


class MonumentController extends Controller
{
    //
    public function listMonument($id){

		$monument = Monument::find($id);

		if($monument){

			return response()->json(

				[
					"id" => $monument->id,
					"name" => $monument->name,
					"info" => $monument->info,
					"image" => $monument->image,
					"id_coordinate" => $monument->coordinates_id,
					"altitude" => $monument->Coordinate->altitude,
					"latitude" => $monument->Coordinate->latitude
					
				]

			);
		}

		return response("Monumento no encontrado");
	}
}
